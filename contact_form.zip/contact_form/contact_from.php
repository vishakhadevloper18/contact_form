<!DOCTYPE html>
<html>
<head>
   
    <title>Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        #captcha {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
    <script>
        function generateCaptcha(length) {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let captcha = '';
            for (let i = 0; i < length; i++) {
                captcha += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            return captcha;
        }

        function initCaptcha() {
            const captchaContainer = document.getElementById('captcha');
            const captchaLength = 6;
            const captchaText = generateCaptcha(captchaLength);
            captchaContainer.textContent = captchaText;
        }

        window.onload = initCaptcha;

        function validateForm() {
            var firstName = document.getElementById("firstName").value.trim();
            var lastName = document.getElementById("lastName").value.trim();
            var mobile = document.getElementById("mobile").value.trim();
            var email = document.getElementById("emailAddress").value.trim();
            var address = document.getElementById("Address").value.trim();
            var captchaInput = document.getElementById("captchaInput").value.trim();

            if (firstName === '' || lastName === '' || mobile === '' || email === '' || address === '' || captchaInput === '') {
                alert("All fields are required!");
                return false;
            }

            var mobileRegex = /^[0-9]{10}$/;
            if (!mobile.match(mobileRegex)) {
                alert("Mobile number should be 10 digits!");
                return false;
            }

            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email.match(emailRegex)) {
                alert("Invalid email format!");
                return false;
            }

            var captchaText = document.getElementById("captcha").textContent.trim();
            if (captchaInput !== captchaText) {
                alert("CAPTCHA verification failed!");
                return false;
            }

            return true;
        }


		function submitForm() {
    if (validateForm()) {
        var formData = new FormData(document.getElementById("contactForm"));
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert("Form submitted successfully!");
                    document.getElementById("contactForm").reset();
                    initCaptcha(); 
                } else {
                    alert("An error occurred while submitting the form. Please try again.");
                }
            }
        };
        xhr.open("POST", "submit_form.php", true);
        xhr.send(formData);
    }
    return false;
}

    </script>
</head>
<body>
    <div class="container">
        <h1>Contact Form</h1>
		<form id="contactForm" action="javascript:void(0)" method="post" onsubmit="return submitForm()">

            <label for="firstName">First Name:</label>
            <input type="text" name="first_name" id="firstName">

            <label for="lastName">Last Name:</label>
            <input type="text" name="last_name" id="lastName">

            <label for="mobile">Mobile:</label>
            <input type="text" name="mobile" id="mobile">

            <label for="Address">Address:</label>
            <input type="text" name="address" id="Address">

            <label for="emailAddress">Email Address:</label>
            <input type="text" name="email" id="emailAddress">

            <div id="captcha"></div>
            <input type="text" id="captchaInput" placeholder="Enter CAPTCHA" required>

            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
