<?php
require 'smtp/PHPMailerAutoload.php'; 
require 'smtp/class.phpmailer.php';
require 'smtp/class.smtp.php';

function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);
    // $mail->SMTPDebug = 3;                             
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'vishakhadeveloper9@gmail.com'; 
    $mail->Password = 'dfyxzdcsbrxzopeq'; 
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';

    $mail->setFrom('vishakhadeveloper9@gmail.com', 'Contact Detail Received');
    $mail->isHTML(true);

    $mail->addAddress($to);
    $mail->Subject = $subject;
    $mail->Body = $message;

    if (!$mail->send()) {
        return 'Error: ' . $mail->ErrorInfo;
    } else {
        return 'Email sent successfully';
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['first_name']) || empty($_POST['last_name']) || empty($_POST['mobile']) || empty($_POST['address']) || empty($_POST['email'])) {
        header("Location: contact_form.php?status=error&message=All%20fields%20are%20required");
        exit;
    }

    $conn = mysqli_connect("localhost", "root", "", "customer");

    if($conn === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    
    $sql = "INSERT INTO contact (firstname, lastname, email, mobile, address) 
            VALUES ('$first_name', '$last_name', '$email', '$mobile', '$address')";
ob_start();

    if(mysqli_query($conn, $sql)){
        $subject = 'Thank you for your submission';
        $message = "Dear $first_name $last_name,<br><br>"
                    . "Thank you for your submission. We have received your contact details.<br><br>"
                    . "Best regards,<br>"
                    . "Support Team";
        $result = sendEmail($email, $subject, $message);
        
        // echo '<script>';
        // echo 'alert("Form submitted successfully!");';
		
        // echo '</script>';
		// exit();
		
    } else {
        echo "ERROR: Hush! Sorry $sql. " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
ob_end_flush();
?>
